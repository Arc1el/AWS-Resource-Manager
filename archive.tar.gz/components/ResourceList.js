import { useState } from 'react';

export default function ResourceList({ resources, onDelete, title, type }) {
  const [selectedResources, setSelectedResources] = useState({});
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [resourcestoDelete, setResourcesToDelete] = useState([]);

  const handleCheckboxChange = (resourceId) => {
    setSelectedResources(prev => ({
      ...prev,
      [resourceId]: !prev[resourceId]
    }));
  };

  const handleDeleteSelected = () => {
    const selectedIds = Object.entries(selectedResources)
      .filter(([_, isSelected]) => isSelected)
      .map(([id]) => id);

    const resourcesToDelete = selectedIds.map(id => {
      const resource = resources.find(r => r.id === id);
      return {
        type: type,
        id: id,
        name: resource.name
      };
    });

    setResourcesToDelete(resourcesToDelete);
    setShowConfirmModal(true);
  };

  const confirmDelete = async () => {
    for (const resource of resourcestoDelete) {
      await onDelete(resource.type, resource.id);
    }
    setSelectedResources({});
    setShowConfirmModal(false);
  };

  const cancelDelete = () => {
    setShowConfirmModal(false);
    setResourcesToDelete([]);
  };

  const renderResourceTable = (resourceList) => (
    <div className="mb-8">
      <table className="min-w-full bg-white border border-gray-300">
        <thead className="bg-gray-100">
          <tr>
            <th className="py-2 px-4 border-b">선택</th>
            <th className="py-2 px-4 border-b">이름</th>
            <th className="py-2 px-4 border-b">ID</th>
            <th className="py-2 px-4 border-b">생성 시간</th>
            <th className="py-2 px-4 border-b">생성자</th>
            <th className="py-2 px-4 border-b">상태</th>
          </tr>
        </thead>
        <tbody>
          {resourceList.length > 0 ? (
            resourceList.map((resource) => (
              <tr key={resource.id} className="hover:bg-gray-50">
                <td className="py-2 px-4 border-b">
                  <input
                    type="checkbox"
                    checked={!!selectedResources[resource.id]}
                    onChange={() => handleCheckboxChange(resource.id)}
                    className="form-checkbox h-5 w-5 text-blue-600"
                  />
                </td>
                <td className="py-2 px-4 border-b">{resource.name}</td>
                <td className="py-2 px-4 border-b">{resource.id}</td>
                <td className="py-2 px-4 border-b">{resource.creationTime}</td>
                <td className="py-2 px-4 border-b">{resource.creator}</td>
                <td className="py-2 px-4 border-b">{resource.state}</td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="6" className="py-4 px-4 text-center">
                {type === 'ec2' ? 'EC2 인스턴스가 없습니다.' :
                 '리소스가 없습니다.'}
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );

  return (
    <div className="container mx-auto px-4">
      {/* <button 
        onClick={handleDeleteSelected}
        className="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded mb-4"
      >
        선택된 항목 삭제
      </button> */}
      {renderResourceTable(resources)}

      {showConfirmModal && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full">
          <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <h3 className="text-lg font-bold mb-4">다음 리소스를 삭제하시겠습니까?</h3>
            <ul className="mb-4">
              {resourcestoDelete.map(resource => (
                <li key={resource.id}>{resource.type}: {resource.id} ({resource.name})</li>
              ))}
            </ul>
            <div className="flex justify-end">
              <button
                onClick={confirmDelete}
                className="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded mr-2"
              >
                확인
              </button>
              <button
                onClick={cancelDelete}
                className="bg-gray-300 hover:bg-gray-400 text-black font-bold py-2 px-4 rounded"
              >
                취소
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
