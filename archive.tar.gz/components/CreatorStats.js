import { useState } from 'react';
import { Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

export default function CreatorStats({ creatorStats }) {
  const [selectedCreator, setSelectedCreator] = useState(null);

  const chartData = {
    labels: creatorStats.map(stat => stat.creator),
    datasets: [
      {
        label: '총 리소스 수',
        data: creatorStats.map(stat => stat.totalResources),
        backgroundColor: 'rgba(75, 192, 192, 0.6)',
      },
      {
        label: '리소스 유형 수',
        data: creatorStats.map(stat => stat.resourceTypes),
        backgroundColor: 'rgba(153, 102, 255, 0.6)',
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: '생성자별 리소스 통계',
      },
    },
  };

  return (
    <div className="mt-8">
      <h2 className="text-2xl font-bold mb-4">생성자별 리소스 통계</h2>
      <Bar data={chartData} options={options} />
      
      <div className="mt-8">
        <h3 className="text-xl font-bold mb-2">생성자별 상세 정보</h3>
        <ul>
          {creatorStats.map(stat => (
            <li key={stat.creator} className="mb-2">
              <button
                onClick={() => setSelectedCreator(stat.creator === selectedCreator ? null : stat.creator)}
                className="text-blue-500 hover:underline"
              >
                {stat.creator}: 총 {stat.totalResources}개 리소스, {stat.resourceTypes}개 유형
              </button>
              {selectedCreator === stat.creator && (
                <ul className="ml-4 mt-2">
                  {Object.entries(stat.details).map(([resourceType, resources]) => (
                    <li key={resourceType}>
                      {resourceType}: {resources.length}개
                      <ul className="ml-4">
                        {resources.map(resource => (
                          <li key={resource.id}>{resource.name || resource.id}</li>
                        ))}
                      </ul>
                    </li>
                  ))}
                </ul>
              )}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
