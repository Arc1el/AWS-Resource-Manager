import React from 'react';

export default function DateRangePicker({ dateRange, onDateRangeChange }) {
  const handleStartDateChange = (e) => {
    onDateRangeChange({ ...dateRange, startDate: new Date(e.target.value) });
  };

  const handleEndDateChange = (e) => {
    onDateRangeChange({ ...dateRange, endDate: new Date(e.target.value) });
  };

  return (
    <div className="flex items-center space-x-4 mb-4">
      <div>
        <label htmlFor="startDate" className="block text-sm font-medium text-gray-700">시작 날짜</label>
        <input
          type="date"
          id="startDate"
          value={dateRange.startDate.toISOString().split('T')[0]}
          onChange={handleStartDateChange}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
        />
      </div>
      <div>
        <label htmlFor="endDate" className="block text-sm font-medium text-gray-700">종료 날짜</label>
        <input
          type="date"
          id="endDate"
          value={dateRange.endDate.toISOString().split('T')[0]}
          onChange={handleEndDateChange}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
        />
      </div>
    </div>
  );
}