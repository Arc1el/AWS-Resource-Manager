// 문자열을 지정된 길이로 자르는 함수
export function truncateString(str, maxLength) {
  if (str.length <= maxLength) return str;
  return str.slice(0, maxLength) + '...';
}

// 생성자 이름을 정제하고 길이를 제한하는 함수
export function cleanCreatorName(creator) {
  const parts = creator.split('/');
  const cleanedName = parts.length > 1 ? parts.slice(1).join('/') : creator;
  return truncateString(cleanedName, 20);
}

export function groupResourcesByCreator(resources) {
  const groupedResources = {};
  
  Object.entries(resources).forEach(([resourceType, resourceList]) => {
    resourceList.forEach(resource => {
      const cleanedCreator = cleanCreatorName(resource.creator || '알 수 없음');
      if (!groupedResources[cleanedCreator]) {
        groupedResources[cleanedCreator] = {};
      }
      if (!groupedResources[cleanedCreator][resourceType]) {
        groupedResources[cleanedCreator][resourceType] = [];
      }
      groupedResources[cleanedCreator][resourceType].push(resource);
    });
  });

  return groupedResources;
}

export function getCreatorStats(groupedResources) {
  return Object.entries(groupedResources).map(([creator, resources]) => {
    const totalResources = Object.values(resources).flat().length;
    const resourceTypes = Object.keys(resources).length;
    
    return {
      creator,
      totalResources,
      resourceTypes,
      details: resources
    };
  }).sort((a, b) => b.totalResources - a.totalResources);
}
