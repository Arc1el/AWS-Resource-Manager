import { GameLiftClient, DescribeFleetAttributesCommand, ListFleetsCommand } from "@aws-sdk/client-gamelift";
import { getResourceCreationEvents, retryWithBackoff } from '../aws';
import { format, utcToZonedTime } from 'date-fns-tz';

const region = process.env.AWS_REGION || "ap-northeast-2";
const TIMEZONE = 'Asia/Seoul';

const gameLiftClient = new GameLiftClient({ region });

async function listGameLiftResources(startDate, endDate) {
    console.log("GameLift 조회 기간:", startDate, "~", endDate);
    
    try {
      const events = await getResourceCreationEvents(startDate, endDate, "CreateFleet", "AWS::GameLift::Fleet");
      console.log("가져온 GameLift 이벤트 수:", events.length);
  
      const currentFleets = await retryWithBackoff(() => getCurrentGameLiftFleets());
      console.log("현재 GameLift Fleet 수:", currentFleets.length);
  
      return events.map(event => {
        const cloudTrailEvent = JSON.parse(event.CloudTrailEvent);
        const fleetId = cloudTrailEvent.responseElements.fleetAttributes.fleetId;
        const currentFleet = currentFleets.find(fleet => fleet.FleetId === fleetId);
  
        return {
          id: fleetId,
          name: currentFleet ? currentFleet.Name : fleetId,
          creationTime: format(utcToZonedTime(new Date(event.EventTime), TIMEZONE), 'yyyy-MM-dd HH:mm:ss'),
          creator: cloudTrailEvent.userIdentity.arn,
          state: currentFleet ? currentFleet.Status : '삭제됨',
        };
      });
    } catch (error) {
      console.error("GameLift 리소스 조회 오류:", error);
      return []; // 오류 발생 시 빈 배열 반환
    }
  }
  
  async function getCurrentGameLiftFleets() {
    const listCommand = new ListFleetsCommand({});
    const listResponse = await retryWithBackoff(() => gameLiftClient.send(listCommand));
    
    if (!listResponse.FleetIds || listResponse.FleetIds.length === 0) {
      console.log("GameLift Fleet이 없습니다.");
      return [];
    }
  
    const describeCommand = new DescribeFleetAttributesCommand({ FleetIds: listResponse.FleetIds });
    const describeResponse = await retryWithBackoff(() => gameLiftClient.send(describeCommand));
    return describeResponse.FleetAttributes || [];
  }

  export { listGameLiftResources };