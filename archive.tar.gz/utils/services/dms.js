import { DatabaseMigrationServiceClient, DescribeReplicationInstancesCommand } from "@aws-sdk/client-database-migration-service";
import { getResourceCreationEvents, retryWithBackoff } from '../aws';
import { format, utcToZonedTime } from 'date-fns-tz';

const region = process.env.AWS_REGION || "ap-northeast-2";
const TIMEZONE = 'Asia/Seoul';

const dmsClient = new DatabaseMigrationServiceClient({ region });


async function listDMSResources(startDate, endDate) {
    console.log("DMS 조회 기간:", startDate, "~", endDate);
    
    try {
      const events = await getResourceCreationEvents(startDate, endDate, "CreateReplicationInstance", "AWS::DMS::ReplicationInstance");
      console.log("가져온 DMS 이벤트 수:", events.length);
  
      const currentInstances = await retryWithBackoff(() => getCurrentDMSInstances());
      console.log("현재 DMS 복제 인스턴스 수:", currentInstances.length);
  
      return events.map(event => {
        const cloudTrailEvent = JSON.parse(event.CloudTrailEvent);
        const instanceId = cloudTrailEvent.requestParameters.replicationInstanceIdentifier;
        const currentInstance = currentInstances.find(instance => instance.ReplicationInstanceIdentifier === instanceId);
  
        return {
          id: instanceId,
          name: instanceId,
          creationTime: format(utcToZonedTime(new Date(event.EventTime), TIMEZONE), 'yyyy-MM-dd HH:mm:ss'),
          creator: cloudTrailEvent.userIdentity.arn,
          state: currentInstance ? currentInstance.ReplicationInstanceStatus : '삭제됨',
        };
      });
    } catch (error) {
      console.error("DMS 리소스 조회 오류:", error);
      throw error;
    }
  }
  
  async function getCurrentDMSInstances() {
    const command = new DescribeReplicationInstancesCommand({});
    const response = await retryWithBackoff(() => dmsClient.send(command));
    return response.ReplicationInstances;
  }

  export { listDMSResources };