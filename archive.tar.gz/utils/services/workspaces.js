import { WorkSpacesClient, DescribeWorkspacesCommand } from "@aws-sdk/client-workspaces";

import { getResourceCreationEvents, retryWithBackoff } from '../aws';
import { format, utcToZonedTime } from 'date-fns-tz';

const region = process.env.AWS_REGION || "ap-northeast-2";
const TIMEZONE = 'Asia/Seoul';

const workSpacesClient = new WorkSpacesClient({ region: process.env.AWS_REGION });


async function listWorkSpacesResources(startDate, endDate) {
    console.log("WorkSpaces 조회 기간:", startDate, "~", endDate);
    
    try {
      const events = await getResourceCreationEvents(startDate, endDate, "CreateWorkspaces", "AWS::WorkSpaces::Workspace");
      console.log("가져온 WorkSpaces 이벤트 수:", events.length);
  
      const currentWorkspaces = await retryWithBackoff(() => getCurrentWorkSpaces());
      console.log("현재 WorkSpaces 수:", currentWorkspaces.length);
  
      return events.map(event => {
        const cloudTrailEvent = JSON.parse(event.CloudTrailEvent);
        const workspaceId = cloudTrailEvent.responseElements.failedRequests[0]?.workspaceId || 
                            cloudTrailEvent.responseElements.pendingRequests[0]?.workspaceId;
        const currentWorkspace = currentWorkspaces.find(ws => ws.WorkspaceId === workspaceId);
  
        return {
          id: workspaceId,
          name: currentWorkspace ? currentWorkspace.UserName : workspaceId,
          creationTime: format(utcToZonedTime(new Date(event.EventTime), TIMEZONE), 'yyyy-MM-dd HH:mm:ss'),
          creator: cloudTrailEvent.userIdentity.arn,
          state: currentWorkspace ? currentWorkspace.State : '삭제됨',
        };
      });
    } catch (error) {
      console.error("WorkSpaces 리소스 조회 오류:", error);
      throw error;
    }
  }
  
  async function getCurrentWorkSpaces() {
    const command = new DescribeWorkspacesCommand({});
    const response = await retryWithBackoff(() => workSpacesClient.send(command));
    return response.Workspaces || [];
  }

  export { listWorkSpacesResources };