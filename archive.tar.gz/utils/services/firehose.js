import { FirehoseClient, ListDeliveryStreamsCommand, DescribeDeliveryStreamCommand } from "@aws-sdk/client-firehose";

import { getResourceCreationEvents, retryWithBackoff } from '../aws';
import { format, utcToZonedTime } from 'date-fns-tz';

const region = process.env.AWS_REGION || "ap-northeast-2";
const TIMEZONE = 'Asia/Seoul';

const firehoseClient = new FirehoseClient({ region });

async function listFirehoseResources(startDate, endDate) {
    console.log("Kinesis Firehose Delivery Stream 조회 기간:", startDate, "~", endDate);
    
    try {
      const events = await getResourceCreationEvents(startDate, endDate, "CreateDeliveryStream", "AWS::KinesisFirehose::DeliveryStream");
      console.log("가져온 Kinesis Firehose Delivery Stream 이벤트 수:", events.length);
  
      const currentStreams = await retryWithBackoff(() => getCurrentFirehoseStreams());
      console.log("현재 Kinesis Firehose Delivery Stream 수:", currentStreams.length);
  
      return events.map(event => {
        const cloudTrailEvent = JSON.parse(event.CloudTrailEvent);
        const streamName = cloudTrailEvent.responseElements.deliveryStreamName;
        const currentStream = currentStreams.find(stream => stream.DeliveryStreamName === streamName);
  
        return {
          id: streamName,
          name: streamName,
          creationTime: format(utcToZonedTime(new Date(event.EventTime), TIMEZONE), 'yyyy-MM-dd HH:mm:ss'),
          creator: cloudTrailEvent.userIdentity.arn,
          state: currentStream ? currentStream.DeliveryStreamStatus : '삭제됨',
        };
      });
    } catch (error) {
      console.error("Kinesis Firehose Delivery Stream 리소스 조회 오류:", error);
      throw error;
    }
  }
  
  async function getCurrentFirehoseStreams() {
    const listCommand = new ListDeliveryStreamsCommand({});
    const listResponse = await retryWithBackoff(() => firehoseClient.send(listCommand));
    const streams = await Promise.all(listResponse.DeliveryStreamNames.map(async (streamName) => {
      const describeCommand = new DescribeDeliveryStreamCommand({ DeliveryStreamName: streamName });
      const describeResponse = await retryWithBackoff(() => firehoseClient.send(describeCommand));
      return describeResponse.DeliveryStreamDescription;
    }));
    return streams;
  }

  export { listFirehoseResources };