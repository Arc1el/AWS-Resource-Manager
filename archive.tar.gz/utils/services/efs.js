import { EFSClient, DescribeFileSystemsCommand } from "@aws-sdk/client-efs";

import { getResourceCreationEvents, retryWithBackoff } from '../aws';
import { format, utcToZonedTime } from 'date-fns-tz';

const region = process.env.AWS_REGION || "ap-northeast-2";
const TIMEZONE = 'Asia/Seoul';

const efsClient = new EFSClient({ region: "ap-northeast-2" });

async function listEFSResources(startDate, endDate) {
    console.log("EFS 조회 기간:", startDate, "~", endDate);
    
    try {
      const events = await getResourceCreationEvents(startDate, endDate, "CreateFileSystem", "AWS::EFS::FileSystem");
      console.log("가져온 EFS 이벤트 수:", events.length);
  
      const currentFileSystems = await retryWithBackoff(() => getCurrentEFSFileSystems());
      console.log("현재 EFS 파일 시스템 수:", currentFileSystems.length);
  
      return events.map(event => {
        const cloudTrailEvent = JSON.parse(event.CloudTrailEvent);
        const fileSystemId = cloudTrailEvent.responseElements.fileSystemId;
        const currentFileSystem = currentFileSystems.find(fs => fs.FileSystemId === fileSystemId);
  
        return {
          id: fileSystemId,
          name: currentFileSystem ? currentFileSystem.Name : fileSystemId,
          creationTime: format(utcToZonedTime(new Date(event.EventTime), TIMEZONE), 'yyyy-MM-dd HH:mm:ss'),
          creator: cloudTrailEvent.userIdentity.arn,
          state: currentFileSystem ? currentFileSystem.LifeCycleState : '삭제됨',
        };
      });
    } catch (error) {
      console.error("EFS 리소스 조회 오류:", error);
      throw error;
    }
  }
  
  async function getCurrentEFSFileSystems() {
    const command = new DescribeFileSystemsCommand({});
    const response = await retryWithBackoff(() => efsClient.send(command));
    return response.FileSystems;
  }

  export { listEFSResources };