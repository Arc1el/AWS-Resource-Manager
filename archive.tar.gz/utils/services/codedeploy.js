import { CodeDeployClient, ListApplicationsCommand, GetApplicationCommand } from "@aws-sdk/client-codedeploy";
import { getResourceCreationEvents, retryWithBackoff } from '../aws';
import { format, utcToZonedTime } from 'date-fns-tz';

const region = process.env.AWS_REGION || "ap-northeast-2";
const TIMEZONE = 'Asia/Seoul';

const codeDeployClient = new CodeDeployClient({ region });

async function listCodeDeployResources(startDate, endDate) {
    console.log("CodeDeploy 조회 기간:", startDate, "~", endDate);
    
    try {
      const events = await getResourceCreationEvents(startDate, endDate, "CreateApplication", "AWS::CodeDeploy::Application");
      console.log("가져온 CodeDeploy 이벤트 수:", events.length);
  
      const currentApplications = await retryWithBackoff(() => getCurrentCodeDeployApplications());
      console.log("현재 CodeDeploy 애플리케이션 수:", currentApplications.length);
  
      return events.map(event => {
        const cloudTrailEvent = JSON.parse(event.CloudTrailEvent);
        const applicationName = cloudTrailEvent.requestParameters.applicationName;
        const currentApplication = currentApplications.find(app => app.applicationName === applicationName);
  
        return {
          id: applicationName,
          name: applicationName,
          creationTime: format(utcToZonedTime(new Date(event.EventTime), TIMEZONE), 'yyyy-MM-dd HH:mm:ss'),
          creator: cloudTrailEvent.userIdentity.arn,
          state: currentApplication ? 'Active' : '삭제됨',
        };
      });
    } catch (error) {
      console.error("CodeDeploy 리소스 조회 오류:", error);
      throw error;
    }
  }
  
  async function getCurrentCodeDeployApplications() {
    const listCommand = new ListApplicationsCommand({});
    const listResponse = await retryWithBackoff(() => codeDeployClient.send(listCommand));
    const applications = await Promise.all(listResponse.applications.map(async (appName) => {
      const getCommand = new GetApplicationCommand({ applicationName: appName });
      const getResponse = await retryWithBackoff(() => codeDeployClient.send(getCommand));
      return getResponse.application;
    }));
    return applications;
  }

  export { listCodeDeployResources };