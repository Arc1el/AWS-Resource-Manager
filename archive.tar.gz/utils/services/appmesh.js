import { AppMeshClient, ListMeshesCommand, DescribeMeshCommand } from "@aws-sdk/client-app-mesh";
import { getResourceCreationEvents, retryWithBackoff } from '../aws';
import { format, utcToZonedTime } from 'date-fns-tz';

const region = process.env.AWS_REGION || "ap-northeast-2";
const TIMEZONE = 'Asia/Seoul';

const appMeshClient = new AppMeshClient({ region });

async function listAppMeshResources(startDate, endDate) {
    console.log("App Mesh 조회 기간:", startDate, "~", endDate);
    
    try {
      const events = await getResourceCreationEvents(startDate, endDate, "CreateMesh", "AWS::AppMesh::Mesh");
      console.log("가져온 App Mesh 이벤트 수:", events.length);
  
      const currentMeshes = await retryWithBackoff(() => getCurrentAppMeshes());
      console.log("재 App Mesh 수:", currentMeshes.length);
  
      return events.map(event => {
        const cloudTrailEvent = JSON.parse(event.CloudTrailEvent);
        const meshName = cloudTrailEvent.requestParameters.meshName;
        const currentMesh = currentMeshes.find(mesh => mesh.meshName === meshName);
  
        return {
          id: meshName,
          name: meshName,
          creationTime: format(utcToZonedTime(new Date(event.EventTime), TIMEZONE), 'yyyy-MM-dd HH:mm:ss'),
          creator: cloudTrailEvent.userIdentity.arn,
          state: currentMesh ? currentMesh.status.status : '삭제됨',
        };
      });
    } catch (error) {
      console.error("App Mesh 리소스 조회 오류:", error);
      throw error;
    }
  }
  
  async function getCurrentAppMeshes() {
    const listCommand = new ListMeshesCommand({});
    const listResponse = await retryWithBackoff(() => appMeshClient.send(listCommand));
    const meshes = await Promise.all(listResponse.meshes.map(async (mesh) => {
      const describeCommand = new DescribeMeshCommand({ meshName: mesh.meshName });
      const describeResponse = await retryWithBackoff(() => appMeshClient.send(describeCommand));
      return describeResponse.mesh;
    }));
    return meshes;
  }

  export { listAppMeshResources };