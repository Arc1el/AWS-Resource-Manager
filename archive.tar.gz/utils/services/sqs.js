import { SQSClient, ListQueuesCommand, GetQueueAttributesCommand } from "@aws-sdk/client-sqs";

import { getResourceCreationEvents, retryWithBackoff } from '../aws';
import { format, utcToZonedTime } from 'date-fns-tz';

const region = process.env.AWS_REGION || "ap-northeast-2";
const TIMEZONE = 'Asia/Seoul';

const sqsClient = new SQSClient({ region: "ap-northeast-2" });

async function listSQSResources(startDate, endDate) {
    console.log("SQS 조회 기간:", startDate, "~", endDate);
    
    try {
      const events = await getResourceCreationEvents(startDate, endDate, "CreateQueue", "AWS::SQS::Queue");
      console.log("가져온 SQS 이벤트 수:", events.length);
  
      const currentQueues = await retryWithBackoff(() => getCurrentSQSQueues());
      console.log("현재 SQS 큐 수:", currentQueues.length);
  
      return events.map(event => {
        const cloudTrailEvent = JSON.parse(event.CloudTrailEvent);
        const queueUrl = cloudTrailEvent.responseElements?.queueUrl;
        if (!queueUrl) {
          console.log("큐 URL을 찾을 수 없습니다:", cloudTrailEvent);
          return null;
        }
        const queueName = queueUrl.split('/').pop();
        const currentQueue = currentQueues.find(queue => queue.QueueUrl === queueUrl);
  
        return {
          id: queueUrl,
          name: queueName,
          creationTime: format(utcToZonedTime(new Date(event.EventTime), TIMEZONE), 'yyyy-MM-dd HH:mm:ss'),
          creator: cloudTrailEvent.userIdentity.arn,
          state: currentQueue ? 'Active' : '삭제됨',
        };
      }).filter(Boolean); // null 값 제거
    } catch (error) {
      console.error("SQS 리소스 조회 오류:", error);
      return []; // 오류 발생 시 빈 배열 반환
    }
  }
  
  async function getCurrentSQSQueues() {
    const listCommand = new ListQueuesCommand({});
    const listResponse = await retryWithBackoff(() => sqsClient.send(listCommand));
    
    if (!listResponse.QueueUrls || listResponse.QueueUrls.length === 0) {
      console.log("SQS 큐가 없습니다.");
      return [];
    }
  
    const queues = await Promise.all(listResponse.QueueUrls.map(async (queueUrl) => {
      const getAttributesCommand = new GetQueueAttributesCommand({ 
        QueueUrl: queueUrl,
        AttributeNames: ['All']
      });
      const attributesResponse = await retryWithBackoff(() => sqsClient.send(getAttributesCommand));
      return { QueueUrl: queueUrl, ...attributesResponse.Attributes };
    }));
    return queues;
  }

  export { listSQSResources };