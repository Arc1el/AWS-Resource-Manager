import { EC2Client, DescribeInstancesCommand } from "@aws-sdk/client-ec2";
import { getResourceCreationEvents, retryWithBackoff } from '../aws';
import { format, utcToZonedTime } from 'date-fns-tz';

const region = process.env.AWS_REGION || "ap-northeast-2";
const ec2Client = new EC2Client({ region });
const TIMEZONE = 'Asia/Seoul';

async function listEC2Resources(startDate, endDate) {
    console.log("조회 기간:", startDate, "~", endDate);
    
    try {
      const events = await getResourceCreationEvents(startDate, endDate, "RunInstances", "AWS::EC2::Instance");
      console.log("가져온 이벤트 수:", events.length);
  
      const currentInstances = await retryWithBackoff(() => getCurrentEC2Instances());
      console.log("현재 인스턴스 수:", currentInstances.length);
  
      return events.map(event => {
        const cloudTrailEvent = JSON.parse(event.CloudTrailEvent);
        const instanceId = cloudTrailEvent.responseElements.instancesSet.items[0].instanceId;
        const currentInstance = currentInstances.find(instance => instance.InstanceId === instanceId);
  
        return {
          id: instanceId,
          name: currentInstance?.Tags?.find(tag => tag.Key === 'Name')?.Value || instanceId,
          creationTime: format(utcToZonedTime(new Date(event.EventTime), TIMEZONE), 'yyyy-MM-dd HH:mm:ss'),
          creator: cloudTrailEvent.userIdentity.arn,
          state: currentInstance ? currentInstance.State.Name : '삭제됨',
        };
      });
    } catch (error) {
      console.error("EC2 리소스 조회 오류:", error);
      throw error;
    }
  }
  
  async function getCurrentEC2Instances() {
    const command = new DescribeInstancesCommand({});
    const response = await retryWithBackoff(() => ec2Client.send(command));
    return response.Reservations.flatMap(reservation => reservation.Instances);
  }
  
  export { listEC2Resources };