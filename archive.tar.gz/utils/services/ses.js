import { SESv2Client, ListConfigurationSetsCommand, GetConfigurationSetCommand } from "@aws-sdk/client-sesv2";
import { getResourceCreationEvents, retryWithBackoff } from '../aws';
import { format, utcToZonedTime } from 'date-fns-tz';

const region = process.env.AWS_REGION || "ap-northeast-2";
const TIMEZONE = 'Asia/Seoul';

const sesClient = new SESv2Client({ region });

async function listSESConfigurationSetResources(startDate, endDate) {
    console.log("SES Configuration Set 조회 기간:", startDate, "~", endDate);
    
    try {
      const events = await getResourceCreationEvents(startDate, endDate, "CreateConfigurationSet", "AWS::SES::ConfigurationSet");
      console.log("가져온 SES Configuration Set 이벤트 수:", events.length);
  
      const currentConfigSets = await retryWithBackoff(() => getCurrentSESConfigurationSets());
      console.log("현재 SES Configuration Set 수:", currentConfigSets.length);
  
      return events.map(event => {
        const cloudTrailEvent = JSON.parse(event.CloudTrailEvent);
        const configSetName = cloudTrailEvent.responseElements.configurationSet.name;
        const currentConfigSet = currentConfigSets.find(set => set.Name === configSetName);
  
        return {
          id: configSetName,
          name: configSetName,
          creationTime: format(utcToZonedTime(new Date(event.EventTime), TIMEZONE), 'yyyy-MM-dd HH:mm:ss'),
          creator: cloudTrailEvent.userIdentity.arn,
          state: currentConfigSet ? 'Active' : '삭제됨',
        };
      });
    } catch (error) {
      console.error("SES Configuration Set 리소스 조회 오류:", error);
      throw error;
    }
  }
  
  async function getCurrentSESConfigurationSets() {
    const command = new ListConfigurationSetsCommand({});
    const response = await retryWithBackoff(() => sesClient.send(command));
    const configSets = await Promise.all(response.ConfigurationSets.map(async (set) => {
      const getCommand = new GetConfigurationSetCommand({ ConfigurationSetName: set.Name });
      const getResponse = await retryWithBackoff(() => sesClient.send(getCommand));
      return getResponse;
    }));
    return configSets;
  }

  export { listSESConfigurationSetResources };