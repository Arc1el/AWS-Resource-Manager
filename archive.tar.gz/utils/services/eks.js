import { EKSClient, DescribeClusterCommand, ListClustersCommand as EKSListClustersCommand } from "@aws-sdk/client-eks";
import { getResourceCreationEvents, retryWithBackoff } from '../aws';
import { format, utcToZonedTime } from 'date-fns-tz';

const region = process.env.AWS_REGION || "ap-northeast-2";
const TIMEZONE = 'Asia/Seoul';

const eksClient = new EKSClient({ region });

async function listEKSResources(startDate, endDate) {
    console.log("EKS 조회 기간:", startDate, "~", endDate);
    
    try {
      const events = await getResourceCreationEvents(startDate, endDate, "CreateCluster", "AWS::EKS::Cluster");
      console.log("가져온 EKS 이벤트 수:", events.length);
  
      const currentClusters = await retryWithBackoff(() => getCurrentEKSClusters());
      console.log("현재 EKS 클러스터 수:", currentClusters.length);
  
      return events.map(event => {
        const cloudTrailEvent = JSON.parse(event.CloudTrailEvent);
        const clusterName = cloudTrailEvent.responseElements.cluster.name;
        const currentCluster = currentClusters.find(cluster => cluster.name === clusterName);
  
        return {
          id: clusterName,
          name: clusterName,
          creationTime: format(utcToZonedTime(new Date(event.EventTime), TIMEZONE), 'yyyy-MM-dd HH:mm:ss'),
          creator: cloudTrailEvent.userIdentity.arn,
          state: currentCluster ? currentCluster.status : '삭제됨',
        };
      });
    } catch (error) {
      console.error("EKS 리소스 조회 오류:", error);
      throw error;
    }
  }
  
  async function getCurrentEKSClusters() {
    const listCommand = new EKSListClustersCommand({});
    const listResponse = await retryWithBackoff(() => eksClient.send(listCommand));
    const clusters = await Promise.all(listResponse.clusters.map(async (clusterName) => {
      const describeCommand = new DescribeClusterCommand({ name: clusterName });
      const describeResponse = await retryWithBackoff(() => eksClient.send(describeCommand));
      return describeResponse.cluster;
    }));
    return clusters;
  }

  export { listEKSResources };