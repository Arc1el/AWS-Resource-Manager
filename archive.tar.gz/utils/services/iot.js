import { IoTClient, ListThingsCommand, DescribeThingCommand } from "@aws-sdk/client-iot";
import { getResourceCreationEvents, retryWithBackoff } from '../aws';
import { format, utcToZonedTime } from 'date-fns-tz';

const region = process.env.AWS_REGION || "ap-northeast-2";
const TIMEZONE = 'Asia/Seoul';

const iotClient = new IoTClient({ region });

async function listIoTThingResources(startDate, endDate) {
    console.log("IoT Thing 조회 기간:", startDate, "~", endDate);
    
    try {
      const events = await getResourceCreationEvents(startDate, endDate, "CreateThing", "AWS::IoT::Thing");
      console.log("가져온 IoT Thing 이벤트 수:", events.length);
  
      const currentThings = await retryWithBackoff(() => getCurrentIoTThings());
      console.log("현재 IoT Thing 수:", currentThings.length);
  
      return events.map(event => {
        const cloudTrailEvent = JSON.parse(event.CloudTrailEvent);
        const thingName = cloudTrailEvent.responseElements.thingName;
        const currentThing = currentThings.find(thing => thing.thingName === thingName);
  
        return {
          id: thingName,
          name: thingName,
          creationTime: format(utcToZonedTime(new Date(event.EventTime), TIMEZONE), 'yyyy-MM-dd HH:mm:ss'),
          creator: cloudTrailEvent.userIdentity.arn,
          state: currentThing ? 'Active' : '삭제됨',
        };
      });
    } catch (error) {
      console.error("IoT Thing 리소스 조회 오류:", error);
      throw error;
    }
  }
  
  async function getCurrentIoTThings() {
    const command = new ListThingsCommand({});
    const response = await retryWithBackoff(() => iotClient.send(command));
    const things = await Promise.all(response.things.map(async (thing) => {
      const describeCommand = new DescribeThingCommand({ thingName: thing.thingName });
      const describeResponse = await retryWithBackoff(() => iotClient.send(describeCommand));
      return describeResponse;
    }));
    return things;
  }

  export { listIoTThingResources };