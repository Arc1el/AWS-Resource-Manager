import { RDSClient, DescribeDBInstancesCommand } from "@aws-sdk/client-rds";
import { getResourceCreationEvents, retryWithBackoff } from '../aws';
import { format, utcToZonedTime } from 'date-fns-tz';

const region = process.env.AWS_REGION || "ap-northeast-2";
const TIMEZONE = 'Asia/Seoul';

const rdsClient = new RDSClient({ region });


async function getRDSCreationEvents(startDate, endDate) {
    return getResourceCreationEvents(startDate, endDate, "CreateDBInstance", "AWS::RDS::DBInstance");
  }
  
  async function listRDSResources(startDate, endDate) {
    console.log("RDS 조회 기간:", startDate, "~", endDate);
    
    try {
      const [currentInstances, creationEvents] = await Promise.all([
        retryWithBackoff(() => getRDSInstances()),
        getRDSCreationEvents(startDate, endDate)
      ]);
  
      const rdsResources = creationEvents.map(event => {
        const cloudTrailEvent = JSON.parse(event.CloudTrailEvent);
        const instanceId = cloudTrailEvent.requestParameters.dBInstanceIdentifier;
        const currentInstance = currentInstances.find(instance => instance.DBInstanceIdentifier === instanceId);
  
        return {
          id: instanceId,
          name: currentInstance?.DBName || instanceId,
          creationTime: format(utcToZonedTime(new Date(event.EventTime), TIMEZONE), 'yyyy-MM-dd HH:mm:ss'),
          creator: cloudTrailEvent.userIdentity.arn || cloudTrailEvent.userIdentity.principalId,
          state: currentInstance ? currentInstance.DBInstanceStatus : '삭제됨',
        };
      });
  
      return rdsResources;
    } catch (error) {
      console.error("RDS 리소스 조회 오류:", error);
      throw error;
    }
  }
  
  async function getRDSInstances() {
    const command = new DescribeDBInstancesCommand({});
    const response = await retryWithBackoff(() => rdsClient.send(command));
    return response.DBInstances;
  }

  export { listRDSResources };