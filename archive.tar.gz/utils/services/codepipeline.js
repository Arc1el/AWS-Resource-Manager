import { CodePipelineClient, ListPipelinesCommand, GetPipelineCommand } from "@aws-sdk/client-codepipeline";
import { getResourceCreationEvents, retryWithBackoff } from '../aws';
import { format, utcToZonedTime } from 'date-fns-tz';

const region = process.env.AWS_REGION || "ap-northeast-2";
const TIMEZONE = 'Asia/Seoul';

const codePipelineClient = new CodePipelineClient({ region });


async function listCodePipelineResources(startDate, endDate) {
    console.log("CodePipeline 조회 간:", startDate, "~", endDate);
    
    try {
      const events = await getResourceCreationEvents(startDate, endDate, "CreatePipeline", "AWS::CodePipeline::Pipeline");
      console.log("가져온 CodePipeline 이벤트 수:", events.length);
  
      const currentPipelines = await retryWithBackoff(() => getCurrentCodePipelines());
      console.log("현재 CodePipeline 파이프라인 수:", currentPipelines.length);
  
      return events.map(event => {
        const cloudTrailEvent = JSON.parse(event.CloudTrailEvent);
        const pipelineName = cloudTrailEvent.requestParameters.pipeline.name;
        const currentPipeline = currentPipelines.find(pipeline => pipeline.name === pipelineName);
  
        return {
          id: pipelineName,
          name: pipelineName,
          creationTime: format(utcToZonedTime(new Date(event.EventTime), TIMEZONE), 'yyyy-MM-dd HH:mm:ss'),
          creator: cloudTrailEvent.userIdentity.arn,
          state: currentPipeline ? currentPipeline.pipelineState : '삭제됨',
        };
      });
    } catch (error) {
      console.error("CodePipeline 리소스 조회 오류:", error);
      throw error;
    }
  }
  
  async function getCurrentCodePipelines() {
    const listCommand = new ListPipelinesCommand({});
    const listResponse = await retryWithBackoff(() => codePipelineClient.send(listCommand));
    const pipelines = await Promise.all(listResponse.pipelines.map(async (pipeline) => {
      const getCommand = new GetPipelineCommand({ name: pipeline.name });
      const getResponse = await retryWithBackoff(() => codePipelineClient.send(getCommand));
      return getResponse.pipeline;
    }));
    return pipelines;
  }

  export { listCodePipelineResources };