import { EMRClient, ListClustersCommand as EMRListCommand, DescribeClusterCommand as EMRDescribeClusterCommand } from "@aws-sdk/client-emr";

import { getResourceCreationEvents, retryWithBackoff } from '../aws';
import { format, utcToZonedTime } from 'date-fns-tz';

const region = process.env.AWS_REGION || "ap-northeast-2";
const TIMEZONE = 'Asia/Seoul';

const emrClient = new EMRClient({ region });

async function listEMRResources(startDate, endDate) {
    console.log("EMR 조회 기간:", startDate, "~", endDate);
    
    try {
      const events = await getResourceCreationEvents(startDate, endDate, "RunJobFlow", "AWS::EMR::Cluster");
      console.log("가져온 EMR 이벤트 수:", events.length);
  
      const currentClusters = await retryWithBackoff(() => getCurrentEMRClusters());
      console.log("현재 EMR 클러스터 수:", currentClusters.length);
  
      return events.map(event => {
        const cloudTrailEvent = JSON.parse(event.CloudTrailEvent);
        const clusterId = cloudTrailEvent.responseElements.jobFlowId;
        const currentCluster = currentClusters.find(cluster => cluster.Id === clusterId);
  
        return {
          id: clusterId,
          name: cloudTrailEvent.requestParameters.name,
          creationTime: format(utcToZonedTime(new Date(event.EventTime), TIMEZONE), 'yyyy-MM-dd HH:mm:ss'),
          creator: cloudTrailEvent.userIdentity.arn,
          state: currentCluster ? currentCluster.Status.State : '삭제됨',
        };
      });
    } catch (error) {
      console.error("EMR 리소스 조회 오류:", error);
      throw error;
    }
  }
  
  async function getCurrentEMRClusters() {
    const listCommand = new EMRListCommand({});
    const listResponse = await retryWithBackoff(() => emrClient.send(listCommand));
    const clusters = await Promise.all(listResponse.Clusters.map(async (cluster) => {
      const describeCommand = new EMRDescribeClusterCommand({ ClusterId: cluster.Id });
      const describeResponse = await retryWithBackoff(() => emrClient.send(describeCommand));
      return describeResponse.Cluster;
    }));
    return clusters;
  }

  export { listEMRResources };