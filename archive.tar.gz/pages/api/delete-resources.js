import { EC2Client, TerminateInstancesCommand } from "@aws-sdk/client-ec2";

// AWS 설정을 위한 환경 변수를 사용하는 것이 좋습니다.
const region = process.env.AWS_REGION || "ap-northeast-2"; // 기본값으로 서울 리전을 사용

export default async function handler(req, res) {
  if (req.method === 'POST') {
    const { resourceType, resourceId } = req.body;
    
    if (!resourceType || !resourceId) {
      return res.status(400).json({ error: 'Resource type and ID are required' });
    }

    try {
      if (resourceType === 'ec2') {
        const ec2Client = new EC2Client({ region });
        const command = new TerminateInstancesCommand({ InstanceIds: [resourceId] });
        const response = await ec2Client.send(command);
        console.log('EC2 인스턴스 종료 요청 완료:', response);
        res.status(200).json({ message: 'EC2 instance termination initiated' });
      } else {
        throw new Error('Unsupported resource type');
      }
    } catch (error) {
      console.error('Error deleting resource:', error);
      res.status(500).json({ error: 'Failed to delete resource', details: error.message });
    }
  } else {
    res.setHeader('Allow', ['POST']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}
