import React, { useState, useEffect } from 'react';
import ResourceList from '../components/ResourceList';
import LoadingIndicator from '../components/LoadingIndicator';
import DateRangePicker from '../components/DateRangePicker';
import CreatorStats from '../components/CreatorStats';
import { groupResourcesByCreator, getCreatorStats, cleanCreatorName } from '../utils/dataProcessing';

export default function Home() {
  const [dateRange, setDateRange] = useState({
    startDate: new Date(new Date().setDate(new Date().getDate() - 7)),
    endDate: new Date()
  });

  const [resources, setResources] = useState({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleDateRangeChange = (newDateRange) => {
    setDateRange(newDateRange);
  };

  const fetchResources = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch(`/api/get-resources?startDate=${dateRange.startDate.toISOString()}&endDate=${dateRange.endDate.toISOString()}`);
      if (!response.ok) {
        throw new Error('API 응답이 올바르지 않습니다.');
      }
      const data = await response.json();
      console.log("받은 데이터:", data);
      setResources(data);
    } catch (error) {
      console.error('리소스 가져오기 오류:', error);
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchResources();
  }, [dateRange]);

  useEffect(() => {
    console.log("업데이트된 resources:", resources);
  }, [resources]);

  const creatorStats = getCreatorStats(groupResourcesByCreator(resources));

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-bold text-gray-900">AWS 리소스 관리자</h1>
        </div>
      </header>
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <DateRangePicker dateRange={dateRange} onDateRangeChange={handleDateRangeChange} />
        <button 
          onClick={fetchResources}
          className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mb-4"
        >
          리소스 조회
        </button>
        {loading ? (
          <LoadingIndicator />
        ) : error ? (
          <p className="text-red-500">{error}</p>
        ) : (
          <>
            {Object.entries(resources).map(([type, typeResources]) => (
              <div key={type} className="mb-8">
                <h2 className="text-2xl font-bold mb-4">
                  {type.toUpperCase() === 'EC2' ? 'EC2 인스턴스' : 
                   type.toUpperCase() === 'RDS' ? 'RDS 데이터베이스' : 
                   type.toUpperCase() === 'SAGEMAKER' ? 'SageMaker 노트북 인스턴스' :
                   type.toUpperCase() === 'ROUTE53' ? 'Route53 Hosted Zones' :
                   type.toUpperCase() === 'CODEBUILD' ? 'CodeBuild 프로젝트' :
                   type.toUpperCase() === 'CODEDEPLOY' ? 'CodeDeploy 애플리케이션' :
                   type.toUpperCase() === 'CODEPIPELINE' ? 'CodePipeline 파이프라인' :
                   type.toUpperCase() === 'KINESIS' ? 'Kinesis 스트림' :
                   type.toUpperCase() === 'OPENSEARCH' ? 'OpenSearch 도메인' :
                   type.toUpperCase() === 'DMS' ? 'DMS 복제 인스턴스' :
                   type.toUpperCase() === 'ECR' ? 'ECR 리포지토리' :
                   type.toUpperCase() === 'ECS' ? 'ECS 클러스터' :
                   type.toUpperCase() === 'EKS' ? 'EKS 클러스터' :
                   type.toUpperCase() === 'APIGATEWAY' ? 'API Gateway REST API' :
                   type.toUpperCase() === 'APPMESH' ? 'App Mesh' :
                   type.toUpperCase() === 'CLOUDFRONT' ? 'CloudFront 배포' :
                   type.toUpperCase() === 'GLUE' ? 'Glue Jobs' :
                   type.toUpperCase() === 'GAMELIFT' ? 'GameLift Fleets' :
                   type.toUpperCase() === 'CHATBOT' ? 'Chatbot Slack Channel Configurations' :
                   type.toUpperCase() === 'DIRECTCONNECT' ? 'Direct Connect 연결' :
                   type.toUpperCase() === 'VPC' ? 'VPC' :
                   type.toUpperCase() === 'MEMORYDB' ? 'MemoryDB 클러스터' :
                   type.toUpperCase() === 'GUARDDUTY' ? 'GuardDuty 디텍터' :
                   type.toUpperCase() === 'WAFV2' ? 'WAFv2 WebACL' :
                   type.toUpperCase() === 'SHIELD' ? 'Shield Protection' :
                   type.toUpperCase() === 'ATHENA' ? 'Athena WorkGroup' :
                   type.toUpperCase() === 'FIREHOSE' ? 'Kinesis Firehose Delivery Stream' :
                   type.toUpperCase() === 'EMR' ? 'EMR Cluster' :
                   type.toUpperCase() === 'MSK' ? 'MSK Cluster' :
                   type.toUpperCase() === 'CONNECT' ? 'Connect Instance' :
                   type.toUpperCase() === 'PINPOINT' ? 'Pinpoint App' :
                   type.toUpperCase() === 'SES' ? 'SES' :
                   type.toUpperCase() === 'IOT' ? 'IoT' :
                   type.toUpperCase() === 'BACKUPPLAN' ? 'Backup Plan' :
                   type.toUpperCase() === 'EFS' ? 'EFS 파일 시스템' :
                   type.toUpperCase() === 'AMAZONMQ' ? 'AmazonMQ Broker' :
                   type.toUpperCase() === 'SQS' ? 'SQS 큐' :
                   type.toUpperCase() === 'KAFKA' ? 'Kafka Cluster' :
                   type.toUpperCase() === 'STEPPARAMETERS' ? 'Step Functions' :
                   type.toUpperCase() === 'APPSTREAM' ? 'AppStream' :
                   type.toUpperCase() === 'WORKSPACES' ? 'WorkSpaces' :
                   type.toUpperCase() === 'BATCHJOBQUEUE' ? 'Batch Job Queue' :
                   type.toUpperCase() === 'ELASTICBEANSTALKAPPLICATION' ? 'Elastic Beanstalk Application' :
                   type.toUpperCase() === 'LAMBDAFUNCTION' ? 'Lambda Function' :
                   `${type.toUpperCase()}`}
                </h2>
                {Array.isArray(typeResources) && typeResources.length > 0 ? (
                  <ResourceList 
                    resources={typeResources.map(resource => ({
                      ...resource,
                      creator: cleanCreatorName(resource.creator || '알 수 없음')
                    }))}
                    onDelete={() => {}} // 삭제 기능이 필요하다면 구현해주세요
                    title={`${type.toUpperCase()} 리소스`} 
                    type={type} 
                  />
                ) : (
                  <p>리소스가 없습니다.</p>
                )}
              </div>
            ))}
            <CreatorStats creatorStats={creatorStats} />
          </>
        )}
      </main>
    </div>
  );
}
