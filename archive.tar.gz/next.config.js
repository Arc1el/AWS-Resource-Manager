module.exports = {
    reactStrictMode: true,
  }